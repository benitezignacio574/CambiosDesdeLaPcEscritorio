document.getElementById('loginButton').addEventListener('click', function() {
    window.location.href = '../HTML/IngresarVendedor.html';
});

document.getElementById('pag').addEventListener('click', function() {
    window.location.href = '../Venta/index.html';
});
  

