document.getElementById('compra').addEventListener('click', function() {
    window.location.href = '../HTML/Ingresar.html';
  });
document.getElementById('vol').addEventListener('click', function() {
    window.location.href = '../HTML/Ingresar.html';
  });